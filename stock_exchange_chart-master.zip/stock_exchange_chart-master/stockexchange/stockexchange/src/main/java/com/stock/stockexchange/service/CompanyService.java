package com.stock.stockexchange.service;

import java.sql.SQLException;
import java.util.List;

import com.stock.stockexchange.model.Company;
import com.stock.stockexchange.model.Sector;
import com.stock.stockexchange.model.User;


public interface CompanyService{

	
	  public Company insertCompany(Company company) throws SQLException;
	  
	  /* public Company updateCompany(Company company) throws SQLException;*/
		public List<Company> getCompanyList() throws SQLException, ClassNotFoundException;
		
		/* 
		 
}*/
		public List<Company> findMatchingCompany(String name);
		List<Company> findCompanyBySector( int id);

		public Company getCompanyById(int id);
}
