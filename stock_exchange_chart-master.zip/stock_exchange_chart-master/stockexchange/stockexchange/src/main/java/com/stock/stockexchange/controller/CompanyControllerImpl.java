package com.stock.stockexchange.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.stock.stockexchange.model.Company;
import com.stock.stockexchange.model.Sector;
import com.stock.stockexchange.model.User;
import com.stock.stockexchange.service.CompanyService;
import com.stock.stockexchange.service.SectorService;



@Controller
public class CompanyControllerImpl {

	
	@Autowired
	private CompanyService companyService;
	
	
	@Autowired
	private SectorService sectorService;
	

	
	
	public Company insertCompany(Company company) throws SQLException {
		companyService.insertCompany(company);
		return company;	
	}



	@RequestMapping(path="/companyList")
	public ModelAndView getCompanyList() throws SQLException, ClassNotFoundException {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("companyList");
		mv.addObject("companyList",companyService.getCompanyList());
		return mv;
	}
	
	
	@RequestMapping(value = "/addCompany", method = RequestMethod.GET)
	public String getCompanyForm(ModelMap model) throws SQLException {
		System.out.println("add company");
		Company company=new Company();
		List<Sector> sectorList=null;
		
		 sectorList = sectorService.fetchSector();
		  System.out.println("hiiii "+sectorService.fetchSector());
		 
		model.addAttribute("sectorList",sectorList);
		model.addAttribute("company", company);
		return "companyForm";
		
		

		
	}
	
	@RequestMapping(value = "/addCompany", method = RequestMethod.POST)
	public String formHandler(@Valid @ModelAttribute("company") Company company,BindingResult result, 
			 Model model) throws SQLException {
		
		
		
		System.out.println(company);
		if(result.hasErrors()){
		System.out.println("eror");
			model.addAttribute("company",company);
			return "companyForm";
		}
		companyService.insertCompany(company);
	
		 return "CompanyView";
	}
	
	@RequestMapping(value="/update/{id}")
	public ModelAndView edit(@PathVariable("id") int id, ModelMap model) 
	{
		
		List<Sector> sectorList=null;
		
		ModelAndView mav=null;
	
			try
			{
			Company company = companyService.getCompanyById(id);
			
			 sectorList = sectorService.fetchSector();
			  System.out.println("hiiii "+sectorService.fetchSector());
			 
			model.addAttribute("sectorList",sectorList);
			model.addAttribute("company", company);
		    }
			catch (Exception e) 
			{
				e.printStackTrace();
			}
		
		mav=new ModelAndView("companyEdit");
		
		return mav;
	}

    //Update the details of the Company	
	
	@RequestMapping(value="/updatesave")
	public String editsave(@ModelAttribute("company") Company company)
			
	{
		
			try
			{
		     companyService.insertCompany(company);
			}
		
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		
		return "redirect:/companyList";
	}


	

	
	
}

