package com.stock.stockexchange.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.stock.stockexchange.model.Company;
import com.stock.stockexchange.model.Stock;

public interface StockDao extends JpaRepository<Stock,Integer>{

	@Query("Select s From Stock s where s.stockExchangeId= :id")
	Stock getStockById(@Param("id") int id);
}
