package com.stock.stockexchange.controller;

import java.sql.SQLException;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.stock.stockexchange.model.Company;
import com.stock.stockexchange.model.Sector;
import com.stock.stockexchange.model.Stock;
import com.stock.stockexchange.service.StockService;

@Controller
public class StockControllerImpl {

	@Autowired
	private StockService stockService;
	
	@RequestMapping(value = "/addStock", method = RequestMethod.GET)
	public String getStockForm(ModelMap model) {
		System.out.println("add stock");
		Stock stock=new Stock();
		
		model.addAttribute("stock", stock);
		return "addStock";
		
		

		
	}
	
	@RequestMapping(value = "/addStock", method = RequestMethod.POST)
	public String processStockForm(@Valid @ModelAttribute("stock") Stock stock, BindingResult result,
			 Model model) throws SQLException {
		
		
		
		System.out.println(stock);
		if(result.hasErrors()){
			System.out.println("eror");
				model.addAttribute("stock",stock);
				return "addStock";
			}
		stockService.insertStock(stock);
	
		 return "redirect:/stockList";
	}
	
	@RequestMapping(path="/stockList")
	public ModelAndView getStockList() throws SQLException {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("stockList");
		mv.addObject("stockList",stockService.getStockList());
		return mv;
	}
	
	@RequestMapping(value="/updateStock/{id}")
	public ModelAndView edit(@PathVariable("id") int id, ModelMap model) 
	{
		
		
		
		ModelAndView mav=null;
	
			try
			{
		    Stock stock = stockService.getStockById(id);
			
			 
			model.addAttribute("stock", stock);
		    }
			catch (Exception e) 
			{
				e.printStackTrace();
			}
		
		mav=new ModelAndView("stockEdit");
		
		return mav;
	}

    //Update the details of the Company	
	
	@RequestMapping(value="/updateStockSave")
	public String editsave(@ModelAttribute("stock") Stock stock)
			
	{
		
			try
			{
		     stockService.insertStock(stock);
			}
		
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		
		return "redirect:/stockList";
	}
}
