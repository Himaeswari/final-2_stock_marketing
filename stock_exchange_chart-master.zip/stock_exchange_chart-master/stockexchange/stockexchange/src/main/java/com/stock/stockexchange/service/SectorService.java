package com.stock.stockexchange.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.data.repository.query.Param;

import com.stock.stockexchange.model.Sector;
import com.stock.stockexchange.model.Stock;

public interface SectorService {

	

	List<Sector> fetchSector();
}
